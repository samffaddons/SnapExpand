# SnapExpand — Text Expander & Snippet Hotkeys (Firefox)

A lightweight text-expansion (macro) add-on. Define short triggers that expand
into longer text anywhere you can type, assign hotkeys to insert snippets
on demand, and optionally add items to the right-click menu. Settings can be
exported/imported as JSON.

- Extension ID: `{005fa338-6366-4dd6-a6d2-24bcb000f3f1}`
- Name shown in Firefox: **SnapExpand — Text Expander & Snippet Hotkeys**

## Install (temporary, for testing)

1. Open Firefox and go to `about:debugging#/runtime/this-firefox`.
2. Click **Load Temporary Add-on…**
3. Select the `manifest.json` file inside this folder.
4. The SnapExpand icon appears in the toolbar. Click it to enable/disable or
   open **Settings**.

This "temporary" install is removed when Firefox restarts — it's meant for
trying it out. See **Permanent install** below for everyday use.

## Permanent install (signed .xpi)

Firefox only auto-updates and permanently loads add-ons that are signed by
Mozilla (or Firefox set to `xpinstall.signatures.required = false`, which is
only available on Developer/Nightly/ESR builds). To get a permanent, signed
build:

1. Create a free account at https://addons.mozilla.org (AMO).
2. Zip the contents of this folder (not the folder itself — `manifest.json`
   must be at the zip root) — a ready-made `snapexpand-firefox.zip` is
   included alongside this README for convenience.
3. Go to **"Submit a New Add-on"** on AMO, choose **"On your own"**
   distribution if you don't want it public, and upload the zip.
4. AMO signs it automatically within a few minutes; download the signed
   `.xpi` and drag it into Firefox (or `about:addons` → gear icon →
   **Install Add-on From File**) to install permanently.

Alternatively, for **Firefox ESR / Developer Edition / Nightly**, you can set
`xpinstall.signatures.required` to `false` in `about:config` and install the
unsigned zip/xpi directly without going through AMO.

## How it works

### Text expansion
Type a trigger word (e.g. `dt`) in any text box, textarea, or editable
region (Gmail compose, comment boxes, etc.). By default, SnapExpand expands
the trigger as soon as you type a space or punctuation right after it — this
"safer" mode avoids accidentally expanding a trigger that's just the start
of a longer word (e.g. a trigger `ph` won't fire while you're typing
`phone` yourself). You can switch to **immediate** mode in Settings if you
prefer instant expansion — in that case, use distinctive triggers (e.g.
prefix them with `;` or `/`, like `;dt`) to avoid collisions.

Triggers only match on a word boundary (start of field, space, punctuation,
etc. before them) — so `dt` won't fire in the middle of `Sundt`.

### Hotkeys
Open a snippet's row in Settings and click **Set hotkey**, then press the
key combination you want (e.g. `F4`, or `Ctrl+Alt+E`). Press **Backspace**
while recording to clear a hotkey, or **Esc** to cancel. With your cursor
in any text field, pressing the hotkey inserts that snippet's text at the
cursor — no trigger word needed.

### Right-click menu
Toggle **"Show in right-click menu"** in a snippet's advanced options
(click the **⋯** button on its row). It will then appear under
**SnapExpand: Insert** when you right-click any editable field.

### Cursor placement
Put `{|}` anywhere inside a replacement to control exactly where the
cursor ends up after expansion — e.g. replacement `Dear {|},\n\nBest,\nSam`
leaves your cursor right after "Dear ".

### Copy to clipboard
Turn on **"Copy expanded text to clipboard by default"** in Settings, or
per-snippet in its advanced options, to also copy the expanded text to your
clipboard whenever it's used.

### Export / Import
In Settings → **Import / Export**, click **Export settings** to download a
JSON backup of everything (snippets + preferences). **Import settings…**
lets you either replace everything or merge into your current list.

## Performance notes

- The background script is a non-persistent event page — it stays unloaded
  until something happens (install, a context-menu click), so it uses no
  memory or CPU while idle.
- The content script only ever reacts to `input`, `keydown`, and `focusin`
  events — there is no polling loop and no timer running while you're not
  typing.
- Trigger matching only scans the last ~60 characters before your cursor
  (not the whole page or field), so it stays fast even in huge documents.
- Password fields (`<input type="password">`) are always skipped.

## Files

```
manifest.json        Extension manifest (Firefox MV2)
background.js         Event page: defaults, context menu, message relay
content.js             Trigger detection, expansion, hotkeys (runs on every page)
options/               Settings UI (snippet list, hotkey recorder, import/export)
popup/                 Toolbar popup (quick enable/disable + link to settings)
icons/                 Extension icons
```

## Known limitations

- Expansion inside cross-origin `<iframe>`s that the page itself restricts
  scripting on (e.g. some payment widgets) may not work — this is a browser
  sandboxing limit, not something an extension can bypass.
- Extremely locked-down rich text editors that block `execCommand` and
  reimplement their own editing model (e.g. some canvas-based editors) may
  not support expansion; SnapExpand falls back to direct DOM editing where
  possible, but a few editors intercept all input themselves.
