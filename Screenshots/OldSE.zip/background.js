"use strict";

/* SnapExpand — background (non-persistent event page, low idle footprint) */

const STORAGE_SETTINGS_KEY = "snapexpand_settings";
const STORAGE_SNIPPETS_KEY = "snapexpand_snippets";
const MENU_ROOT_ID = "snapexpand-root";

const DEFAULT_SETTINGS = {
  enabled: true,
  expansionMode: "delimiter", // "delimiter" | "immediate"
  delimiterChars: " \t\n.,!?;:)",
  caseSensitive: false,
  copyToClipboard: false,
  theme: "auto"
};

function uid() {
  return "sx-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
}

const DEFAULT_SNIPPETS = [
  {
    id: uid(),
    trigger: "dt",
    replacement: "date and time",
    hotkey: null,
    enabled: true,
    caseSensitive: null,
    copyToClipboard: null,
    contextMenu: true
  },
  {
    id: uid(),
    trigger: "ph",
    replacement: "phone number",
    hotkey: null,
    enabled: true,
    caseSensitive: null,
    copyToClipboard: null,
    contextMenu: true
  },
  {
    id: uid(),
    trigger: "sig",
    replacement: "Best regards,\nSam",
    hotkey: "F4",
    enabled: true,
    caseSensitive: null,
    copyToClipboard: null,
    contextMenu: true
  }
];

async function ensureDefaults() {
  const stored = await browser.storage.local.get([STORAGE_SETTINGS_KEY, STORAGE_SNIPPETS_KEY]);
  const toSet = {};
  if (!stored[STORAGE_SETTINGS_KEY]) toSet[STORAGE_SETTINGS_KEY] = DEFAULT_SETTINGS;
  if (!stored[STORAGE_SNIPPETS_KEY]) toSet[STORAGE_SNIPPETS_KEY] = DEFAULT_SNIPPETS;
  if (Object.keys(toSet).length) await browser.storage.local.set(toSet);
}

browser.runtime.onInstalled.addListener(() => {
  ensureDefaults().then(rebuildContextMenu);
});

// In case the event page was suspended and woken by a menu click etc.
ensureDefaults().then(rebuildContextMenu);

function truncate(str, n) {
  if (!str) return "";
  return str.length > n ? str.slice(0, n - 1) + "…" : str;
}

async function rebuildContextMenu() {
  if (!browser.contextMenus) return;
  await browser.contextMenus.removeAll();

  const { [STORAGE_SNIPPETS_KEY]: snippets = [] } = await browser.storage.local.get(STORAGE_SNIPPETS_KEY);
  const eligible = snippets.filter((s) => s.enabled && s.contextMenu);

  if (!eligible.length) return;

  browser.contextMenus.create({
    id: MENU_ROOT_ID,
    title: "SnapExpand: Insert",
    contexts: ["editable"]
  });

  for (const s of eligible) {
    browser.contextMenus.create({
      id: "snapexpand-insert-" + s.id,
      parentId: MENU_ROOT_ID,
      title: `${s.trigger} → ${truncate(s.replacement.replace(/\s+/g, " "), 40)}`,
      contexts: ["editable"]
    });
  }
}

browser.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[STORAGE_SNIPPETS_KEY]) {
    rebuildContextMenu();
  }
});

if (browser.contextMenus) {
  browser.contextMenus.onClicked.addListener((info, tab) => {
    if (!info.menuItemId.toString().startsWith("snapexpand-insert-")) return;
    const id = info.menuItemId.toString().slice("snapexpand-insert-".length);
    browser.tabs.sendMessage(
      tab.id,
      { type: "snapexpand-insert-by-id", id },
      { frameId: info.frameId }
    ).catch(() => {});
  });
}

// Simple message relay for popup -> query state, if ever needed.
browser.runtime.onMessage.addListener((msg) => {
  if (msg && msg.type === "snapexpand-rebuild-menu") {
    rebuildContextMenu();
  }
});
