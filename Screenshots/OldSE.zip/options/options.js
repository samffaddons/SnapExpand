"use strict";

const STORAGE_SETTINGS_KEY = "snapexpand_settings";
const STORAGE_SNIPPETS_KEY = "snapexpand_snippets";

const DEFAULT_SETTINGS = {
  enabled: true,
  expansionMode: "delimiter",
  delimiterChars: " \t\n.,!?;:)",
  caseSensitive: false,
  copyToClipboard: false,
  theme: "auto"
};

let settings = Object.assign({}, DEFAULT_SETTINGS);
let snippets = [];
let saveTimer = null;
let recordingRow = null; // row currently capturing a hotkey

function uid() {
  return "sx-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
}

// ---------- load ----------

async function init() {
  const data = await browser.storage.local.get([STORAGE_SETTINGS_KEY, STORAGE_SNIPPETS_KEY]);
  settings = Object.assign({}, DEFAULT_SETTINGS, data[STORAGE_SETTINGS_KEY] || {});
  snippets = data[STORAGE_SNIPPETS_KEY] || [];
  applyTheme();
  renderSettings();
  renderSnippetList();
  wireGlobalHandlers();
}

function applyTheme() {
  document.body.setAttribute("data-theme", settings.theme === "auto" ? "" : settings.theme);
}

// ---------- persistence ----------

function scheduleSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(persist, 250);
}

async function persist() {
  await browser.storage.local.set({
    [STORAGE_SETTINGS_KEY]: settings,
    [STORAGE_SNIPPETS_KEY]: snippets
  });
  flashSaved();
}

function flashSaved() {
  const el = document.getElementById("saveIndicator");
  el.classList.add("visible");
  clearTimeout(flashSaved._t);
  flashSaved._t = setTimeout(() => el.classList.remove("visible"), 900);
}

// ---------- general settings ----------

function renderSettings() {
  document.getElementById("optEnabled").checked = settings.enabled;
  document.getElementById("optExpansionMode").value = settings.expansionMode;
  document.getElementById("optDelimiters").value = settings.delimiterChars;
  document.getElementById("optCaseSensitive").checked = settings.caseSensitive;
  document.getElementById("optCopyClipboard").checked = settings.copyToClipboard;
  document.getElementById("optTheme").value = settings.theme;
  toggleDelimiterRow();
}

function toggleDelimiterRow() {
  document.getElementById("delimiterRow").style.display =
    settings.expansionMode === "delimiter" ? "flex" : "none";
}

function wireGlobalHandlers() {
  document.getElementById("optEnabled").addEventListener("change", (e) => {
    settings.enabled = e.target.checked;
    scheduleSave();
  });
  document.getElementById("optExpansionMode").addEventListener("change", (e) => {
    settings.expansionMode = e.target.value;
    toggleDelimiterRow();
    scheduleSave();
  });
  document.getElementById("optDelimiters").addEventListener("input", (e) => {
    settings.delimiterChars = e.target.value;
    scheduleSave();
  });
  document.getElementById("optCaseSensitive").addEventListener("change", (e) => {
    settings.caseSensitive = e.target.checked;
    scheduleSave();
  });
  document.getElementById("optCopyClipboard").addEventListener("change", (e) => {
    settings.copyToClipboard = e.target.checked;
    scheduleSave();
  });
  document.getElementById("optTheme").addEventListener("change", (e) => {
    settings.theme = e.target.value;
    applyTheme();
    scheduleSave();
  });

  document.getElementById("btnAddSnippet").addEventListener("click", addSnippet);
  document.getElementById("searchBox").addEventListener("input", renderSnippetList);

  document.getElementById("btnExport").addEventListener("click", exportSettings);
  document.getElementById("btnImport").addEventListener("click", () => {
    document.getElementById("fileImport").click();
  });
  document.getElementById("fileImport").addEventListener("change", importSettings);

  document.addEventListener("keydown", handleGlobalKeydownForRecorder, true);
}

// ---------- snippet CRUD ----------

function addSnippet() {
  const snip = {
    id: uid(),
    trigger: "",
    replacement: "",
    hotkey: null,
    enabled: true,
    caseSensitive: null,
    copyToClipboard: null,
    contextMenu: false
  };
  snippets.unshift(snip);
  scheduleSave();
  renderSnippetList();
  const row = document.querySelector(`.snippet-row[data-id="${snip.id}"] .trigger`);
  if (row) row.focus();
}

function deleteSnippet(id) {
  snippets = snippets.filter((s) => s.id !== id);
  scheduleSave();
  renderSnippetList();
}

function findSnippet(id) {
  return snippets.find((s) => s.id === id);
}

// ---------- rendering ----------

function renderSnippetList() {
  const container = document.getElementById("snippetList");
  const emptyState = document.getElementById("emptyState");
  const query = document.getElementById("searchBox").value.trim().toLowerCase();
  container.innerHTML = "";

  const filtered = query
    ? snippets.filter(
        (s) =>
          s.trigger.toLowerCase().includes(query) ||
          s.replacement.toLowerCase().includes(query)
      )
    : snippets;

  emptyState.hidden = snippets.length !== 0;

  const template = document.getElementById("snippetRowTemplate");
  for (const snip of filtered) {
    const node = template.content.cloneNode(true);
    const row = node.querySelector(".snippet-row");
    row.dataset.id = snip.id;

    const triggerInput = row.querySelector(".trigger");
    const replacementInput = row.querySelector(".replacement");
    const hotkeyBtn = row.querySelector(".hotkey-btn");
    const hotkeyLabel = row.querySelector(".hotkey-label");
    const advToggle = row.querySelector(".adv-toggle");
    const advPanel = row.querySelector(".snippet-advanced");
    const toggleEnabled = row.querySelector(".toggle-enabled");
    const deleteBtn = row.querySelector(".delete-btn");
    const advContextMenu = row.querySelector(".adv-context-menu");
    const advCase = row.querySelector(".adv-case");
    const advClipboard = row.querySelector(".adv-clipboard");

    triggerInput.value = snip.trigger;
    replacementInput.value = snip.replacement;
    autoGrow(replacementInput);
    toggleEnabled.checked = snip.enabled;
    advContextMenu.checked = !!snip.contextMenu;
    advCase.value = snip.caseSensitive == null ? "inherit" : String(snip.caseSensitive);
    advClipboard.value = snip.copyToClipboard == null ? "inherit" : String(snip.copyToClipboard);
    updateHotkeyLabel(hotkeyBtn, hotkeyLabel, snip.hotkey);

    triggerInput.addEventListener("input", () => {
      snip.trigger = triggerInput.value.trim();
      scheduleSave();
    });
    replacementInput.addEventListener("input", () => {
      snip.replacement = replacementInput.value;
      autoGrow(replacementInput);
      scheduleSave();
    });
    toggleEnabled.addEventListener("change", () => {
      snip.enabled = toggleEnabled.checked;
      scheduleSave();
    });
    deleteBtn.addEventListener("click", () => {
      if (snip.trigger || snip.replacement) {
        if (!confirm(`Delete snippet "${snip.trigger || "(untitled)"}"?`)) return;
      }
      deleteSnippet(snip.id);
    });
    advToggle.addEventListener("click", () => {
      advPanel.hidden = !advPanel.hidden;
    });
    advContextMenu.addEventListener("change", () => {
      snip.contextMenu = advContextMenu.checked;
      scheduleSave();
    });
    advCase.addEventListener("change", () => {
      snip.caseSensitive = advCase.value === "inherit" ? null : advCase.value === "true";
      scheduleSave();
    });
    advClipboard.addEventListener("change", () => {
      snip.copyToClipboard = advClipboard.value === "inherit" ? null : advClipboard.value === "true";
      scheduleSave();
    });

    hotkeyBtn.addEventListener("click", () => startRecordingHotkey(snip, hotkeyBtn, hotkeyLabel));

    container.appendChild(node);
  }
}

function autoGrow(textarea) {
  textarea.style.height = "auto";
  textarea.style.height = Math.min(textarea.scrollHeight, 220) + "px";
}

function updateHotkeyLabel(btn, label, hotkey) {
  if (hotkey) {
    label.textContent = hotkey;
    btn.classList.add("assigned");
  } else {
    label.textContent = "Set hotkey";
    btn.classList.remove("assigned");
  }
}

// ---------- hotkey recorder ----------

function startRecordingHotkey(snip, btn, label) {
  if (recordingRow && recordingRow.btn !== btn) stopRecordingHotkey(false);
  recordingRow = { snip, btn, label };
  btn.classList.add("recording");
  label.textContent = "Press keys… (Esc to cancel, Backspace to clear)";
}

function stopRecordingHotkey(commit) {
  if (!recordingRow) return;
  recordingRow.btn.classList.remove("recording");
  updateHotkeyLabel(recordingRow.btn, recordingRow.label, recordingRow.snip.hotkey);
  recordingRow = null;
}

function getEventSignature(e) {
  const key = e.key;
  if (["Control", "Alt", "Shift", "Meta"].includes(key)) return null;
  const parts = [];
  if (e.ctrlKey) parts.push("Ctrl");
  if (e.altKey) parts.push("Alt");
  if (e.shiftKey) parts.push("Shift");
  if (e.metaKey) parts.push("Meta");
  let k = key;
  if (k === " ") k = "Space";
  else if (k.length === 1) k = k.toUpperCase();
  parts.push(k);
  return parts.join("+");
}

function handleGlobalKeydownForRecorder(e) {
  if (!recordingRow) return;
  e.preventDefault();
  e.stopPropagation();

  if (e.key === "Escape") {
    stopRecordingHotkey(false);
    return;
  }
  if (e.key === "Backspace" || e.key === "Delete") {
    recordingRow.snip.hotkey = null;
    scheduleSave();
    stopRecordingHotkey(true);
    return;
  }

  const sig = getEventSignature(e);
  if (!sig) return; // modifier-only keypress, keep listening

  const conflict = snippets.find((s) => s.hotkey === sig && s.id !== recordingRow.snip.id);
  if (conflict) {
    recordingRow.label.textContent = `"${sig}" already used by "${conflict.trigger || "untitled"}"`;
    return;
  }

  recordingRow.snip.hotkey = sig;
  scheduleSave();
  stopRecordingHotkey(true);
  renderSnippetList();
}

// ---------- import / export ----------

function exportSettings() {
  const payload = {
    app: "SnapExpand",
    exportedAt: new Date().toISOString(),
    version: 1,
    settings,
    snippets
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `snapexpand-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

async function importSettings(e) {
  const file = e.target.files[0];
  e.target.value = "";
  if (!file) return;

  let parsed;
  try {
    parsed = JSON.parse(await file.text());
  } catch (err) {
    alert("That file isn't valid JSON.");
    return;
  }
  if (!parsed || !Array.isArray(parsed.snippets)) {
    alert("This doesn't look like a SnapExpand export file.");
    return;
  }

  const mode = confirm(
    "Click OK to REPLACE all current snippets/settings with the imported file.\n" +
      "Click Cancel to MERGE the imported snippets into your existing list instead."
  )
    ? "replace"
    : "merge";

  if (mode === "replace") {
    settings = Object.assign({}, DEFAULT_SETTINGS, parsed.settings || {});
    snippets = parsed.snippets.map(normalizeImported);
  } else {
    const existingTriggers = new Set(snippets.map((s) => s.trigger.toLowerCase()));
    for (const raw of parsed.snippets) {
      const snip = normalizeImported(raw);
      if (existingTriggers.has(snip.trigger.toLowerCase())) {
        snip.id = uid(); // keep as a duplicate rather than silently overwrite
      }
      snippets.push(snip);
    }
  }

  await persist();
  applyTheme();
  renderSettings();
  renderSnippetList();
  alert("Import complete.");
}

function normalizeImported(raw) {
  return {
    id: raw.id || uid(),
    trigger: String(raw.trigger || ""),
    replacement: String(raw.replacement || ""),
    hotkey: raw.hotkey || null,
    enabled: raw.enabled !== false,
    caseSensitive: raw.caseSensitive == null ? null : !!raw.caseSensitive,
    copyToClipboard: raw.copyToClipboard == null ? null : !!raw.copyToClipboard,
    contextMenu: !!raw.contextMenu
  };
}

init();
