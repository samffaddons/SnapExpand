"use strict";

/* SnapExpand — content script
 * Runs in every frame. Purely event-driven (input/keydown/focusin listeners),
 * no polling, no timers while idle — keeps CPU/resource usage negligible.
 */

(function () {
  if (window.__snapexpandInstalled) return;
  window.__snapexpandInstalled = true;

  const STORAGE_SETTINGS_KEY = "snapexpand_settings";
  const STORAGE_SNIPPETS_KEY = "snapexpand_snippets";
  const MAX_LOOKBACK = 60; // characters scanned back from caret; bounds cost on huge fields
  const CURSOR_TOKEN = "{|}";

  let settings = {
    enabled: true,
    expansionMode: "delimiter",
    delimiterChars: " \t\n.,!?;:)",
    caseSensitive: false,
    copyToClipboard: false,
    theme: "auto"
  };
  let snippets = []; // full list, cached
  let activeSnippets = []; // enabled, sorted by trigger length desc
  let hotkeyMap = new Map(); // signature -> snippet
  let delimiterSet = new Set(settings.delimiterChars.split(""));

  let lastEditable = null; // last focused editable element, used for context-menu inserts
  let isComposing = false; // true during IME composition — never expand mid-composition

  function rebuildIndexes() {
    activeSnippets = snippets
      .filter((s) => s.enabled && s.trigger)
      .slice()
      .sort((a, b) => b.trigger.length - a.trigger.length);

    hotkeyMap = new Map();
    for (const s of snippets) {
      if (s.enabled && s.hotkey) hotkeyMap.set(s.hotkey, s);
    }

    delimiterSet = new Set((settings.delimiterChars || "").split(""));
  }

  function loadFromStorage() {
    return browser.storage.local
      .get([STORAGE_SETTINGS_KEY, STORAGE_SNIPPETS_KEY])
      .then((data) => {
        if (data[STORAGE_SETTINGS_KEY]) settings = Object.assign(settings, data[STORAGE_SETTINGS_KEY]);
        if (data[STORAGE_SNIPPETS_KEY]) snippets = data[STORAGE_SNIPPETS_KEY];
        rebuildIndexes();
      })
      .catch(() => {});
  }

  loadFromStorage();

  browser.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (changes[STORAGE_SETTINGS_KEY]) settings = Object.assign(settings, changes[STORAGE_SETTINGS_KEY].newValue);
    if (changes[STORAGE_SNIPPETS_KEY]) snippets = changes[STORAGE_SNIPPETS_KEY].newValue || [];
    rebuildIndexes();
  });

  // ---------- element helpers ----------

  const TEXTY_INPUT_TYPES = new Set([
    "text", "search", "url", "tel", "email", "", null, undefined
  ]);

  function isEditable(el) {
    if (!el) return false;
    if (el.isContentEditable) return true;
    const tag = el.tagName;
    if (tag === "TEXTAREA") return !el.readOnly && !el.disabled;
    if (tag === "INPUT") {
      return TEXTY_INPUT_TYPES.has(el.type) && !el.readOnly && !el.disabled;
    }
    return false;
  }

  function isPlainField(el) {
    return el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA");
  }

  // ---------- reading text around the caret ----------

  function getPlainFieldContext(el) {
    if (el.selectionStart == null || el.selectionStart !== el.selectionEnd) return null; // skip if there's a selection
    const caret = el.selectionStart;
    const start = Math.max(0, caret - MAX_LOOKBACK);
    return { text: el.value.slice(start, caret), caret, fieldStart: start };
  }

  function getPrecedingTextCE(root, node, offset) {
    let text = node.nodeType === Node.TEXT_NODE ? node.data.slice(0, offset) : "";
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    walker.currentNode = node;
    let prev;
    while (text.length < MAX_LOOKBACK && (prev = walker.previousNode())) {
      text = prev.data + text;
    }
    if (text.length > MAX_LOOKBACK) text = text.slice(text.length - MAX_LOOKBACK);
    return text;
  }

  function getContentEditableContext(el) {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0 || !sel.isCollapsed) return null;
    const range = sel.getRangeAt(0);
    if (!el.contains(range.startContainer)) return null;
    const text = getPrecedingTextCE(el, range.startContainer, range.startOffset);
    return { text, range };
  }

  // ---------- trigger matching ----------

  function findMatch(precedingText, requireDelimiterAt) {
    // requireDelimiterAt: if set, precedingText's LAST char must be a delimiter,
    // and the trigger must sit immediately before that delimiter.
    let scanText = precedingText;
    if (requireDelimiterAt) {
      const lastChar = scanText.slice(-1);
      if (!delimiterSet.has(lastChar)) return null;
      scanText = scanText.slice(0, -1); // drop delimiter for trigger comparison
    }

    for (const snip of activeSnippets) {
      const trig = snip.trigger;
      const caseSensitive = snip.caseSensitive != null ? snip.caseSensitive : settings.caseSensitive;
      const hay = caseSensitive ? scanText : scanText.toLowerCase();
      const needle = caseSensitive ? trig : trig.toLowerCase();
      if (!hay.endsWith(needle)) continue;

      const boundaryIndex = hay.length - needle.length;
      if (boundaryIndex > 0) {
        const boundaryChar = scanText[boundaryIndex - 1];
        if (/[a-zA-Z0-9_]/.test(boundaryChar)) continue; // must be a whole "word" trigger
      }
      return { snippet: snip, triggerLen: needle.length, consumedDelimiter: !!requireDelimiterAt };
    }
    return null;
  }

  // ---------- performing the replacement ----------

  function splitCursorToken(replacement) {
    const idx = replacement.indexOf(CURSOR_TOKEN);
    if (idx === -1) return { before: replacement, after: "", hasCursor: false };
    return {
      before: replacement.slice(0, idx),
      after: replacement.slice(idx + CURSOR_TOKEN.length),
      hasCursor: true
    };
  }

  function copyToClipboardIfNeeded(snip, plainText) {
    const shouldCopy = snip.copyToClipboard != null ? snip.copyToClipboard : settings.copyToClipboard;
    if (!shouldCopy) return;
    navigator.clipboard.writeText(plainText).catch(() => {});
  }

  function expandInPlainField(el, snip, triggerStart, caretEnd, keepTrailingDelimiter) {
    const { before, after, hasCursor } = splitCursorToken(snip.replacement);
    const full = before + after;

    el.setSelectionRange(triggerStart, caretEnd);
    const ok = document.execCommand("insertText", false, full);
    if (!ok) {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      const newValue = el.value.slice(0, triggerStart) + full + el.value.slice(caretEnd);
      setter.call(el, newValue);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }

    const newCaret = hasCursor ? triggerStart + before.length : triggerStart + full.length;
    el.setSelectionRange(newCaret, newCaret);
    copyToClipboardIfNeeded(snip, full);
  }

  function buildForwardRange(root, startNode, startOffset, charCount) {
    // Build a collapsed range `charCount` characters after (startNode, startOffset).
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    walker.currentNode = startNode;
    let node = startNode;
    let offset = startOffset;
    let remaining = charCount;
    const avail = node.nodeType === Node.TEXT_NODE ? node.data.length - offset : 0;
    if (remaining <= avail) {
      offset += remaining;
      remaining = 0;
    } else {
      remaining -= avail;
      let next;
      while (remaining > 0 && (next = walker.nextNode())) {
        const len = next.data.length;
        if (remaining <= len) {
          node = next;
          offset = remaining;
          remaining = 0;
        } else {
          remaining -= len;
        }
      }
    }
    const r = document.createRange();
    r.setStart(node, offset);
    r.collapse(true);
    return r;
  }

  function expandInContentEditable(el, snip, range, triggerLen) {
    const { before, after, hasCursor } = splitCursorToken(snip.replacement);
    const full = before + after;

    // Extend range backward by triggerLen characters to select the trigger text.
    const startNode = range.startContainer;
    const startOffset = range.startOffset;
    const backRange = buildBackwardRange(el, startNode, startOffset, triggerLen);

    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(backRange);

    const ok = document.execCommand("insertText", false, full);
    if (!ok) {
      backRange.deleteContents();
      backRange.insertNode(document.createTextNode(full));
      sel.removeAllRanges();
      sel.addRange(backRange);
      sel.collapseToEnd();
    }

    if (hasCursor) {
      const sel2 = window.getSelection();
      if (sel2.rangeCount) {
        const caretRange = sel2.getRangeAt(0);
        // caret is currently at end of inserted text; move it back by after.length
        const placed = buildBackwardRange(el, caretRange.endContainer, caretRange.endOffset, after.length);
        sel2.removeAllRanges();
        sel2.addRange(placed);
      }
    }

    copyToClipboardIfNeeded(snip, full);
  }

  function buildBackwardRange(root, endNode, endOffset, charCount) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    walker.currentNode = endNode;
    let node = endNode;
    let offset = endOffset;
    let remaining = charCount;

    if (remaining <= offset) {
      offset -= remaining;
    } else {
      remaining -= offset;
      let prev;
      while (remaining > 0 && (prev = walker.previousNode())) {
        const len = prev.data.length;
        if (remaining <= len) {
          node = prev;
          offset = len - remaining;
          remaining = 0;
        } else {
          remaining -= len;
        }
      }
    }
    const r = document.createRange();
    r.setStart(node, offset);
    r.setEnd(endNode, endOffset);
    return r;
  }

  // Pure insertion at caret (used by hotkeys & context menu — no trigger text to remove).
  function insertAtCaret(el, snip) {
    if (!isEditable(el)) return;
    const { before, after, hasCursor } = splitCursorToken(snip.replacement);
    const full = before + after;

    if (isPlainField(el)) {
      const start = el.selectionStart != null ? el.selectionStart : el.value.length;
      const end = el.selectionEnd != null ? el.selectionEnd : el.value.length;
      el.focus();
      el.setSelectionRange(start, end);
      const ok = document.execCommand("insertText", false, full);
      if (!ok) {
        const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
        const newValue = el.value.slice(0, start) + full + el.value.slice(end);
        setter.call(el, newValue);
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
      }
      const newCaret = hasCursor ? start + before.length : start + full.length;
      el.setSelectionRange(newCaret, newCaret);
    } else if (el.isContentEditable) {
      el.focus();
      const sel = window.getSelection();
      if (!sel.rangeCount || !el.contains(sel.getRangeAt(0).startContainer)) {
        const r = document.createRange();
        r.selectNodeContents(el);
        r.collapse(false);
        sel.removeAllRanges();
        sel.addRange(r);
      }
      const ok = document.execCommand("insertText", false, full);
      if (!ok) {
        const range = sel.getRangeAt(0);
        range.deleteContents();
        const tn = document.createTextNode(full);
        range.insertNode(tn);
        range.setStartAfter(tn);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
      }
    }
    copyToClipboardIfNeeded(snip, full);
  }

  // ---------- event handlers ----------

  document.addEventListener(
    "focusin",
    (e) => {
      if (isEditable(e.target)) lastEditable = e.target;
    },
    true
  );

  document.addEventListener("compositionstart", () => { isComposing = true; }, true);
  document.addEventListener("compositionend", () => { isComposing = false; }, true);

  document.addEventListener(
    "input",
    (e) => {
      if (!settings.enabled || isComposing || !activeSnippets.length) return;
      const el = e.target;
      if (!isEditable(el)) return;
      if (el.tagName === "INPUT" && el.type === "password") return;

      const requireDelimiter = settings.expansionMode === "delimiter";

      if (isPlainField(el)) {
        const ctx = getPlainFieldContext(el);
        if (!ctx) return;
        const match = findMatch(ctx.text, requireDelimiter);
        if (!match) return;
        const caretForTrigger = requireDelimiter ? ctx.caret - 1 : ctx.caret;
        const triggerStart = caretForTrigger - match.triggerLen;
        expandInPlainField(el, match.snippet, triggerStart, caretForTrigger);
      } else if (el.isContentEditable) {
        const ctx = getContentEditableContext(el);
        if (!ctx) return;
        const match = findMatch(ctx.text, requireDelimiter);
        if (!match) return;

        let workingRange = ctx.range;
        if (requireDelimiter) {
          // Move the working point back one char (before the delimiter) then expand.
          workingRange = buildBackwardRange(el, ctx.range.startContainer, ctx.range.startOffset, 1);
        }
        expandInContentEditable(el, match.snippet, workingRange, match.triggerLen);
      }
    },
    true
  );

  function getEventSignature(e) {
    const key = e.key;
    if (["Control", "Alt", "Shift", "Meta"].includes(key)) return null;
    const parts = [];
    if (e.ctrlKey) parts.push("Ctrl");
    if (e.altKey) parts.push("Alt");
    if (e.shiftKey) parts.push("Shift");
    if (e.metaKey) parts.push("Meta");
    let k = key;
    if (k === " ") k = "Space";
    else if (k.length === 1) k = k.toUpperCase();
    parts.push(k);
    return parts.join("+");
  }

  document.addEventListener(
    "keydown",
    (e) => {
      if (!settings.enabled || !hotkeyMap.size) return;
      const sig = getEventSignature(e);
      if (!sig) return;
      const snip = hotkeyMap.get(sig);
      if (!snip) return;

      const target = isEditable(document.activeElement) ? document.activeElement : lastEditable;
      if (!isEditable(target)) return;

      e.preventDefault();
      e.stopPropagation();
      insertAtCaret(target, snip);
    },
    true
  );

  browser.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "snapexpand-insert-by-id") return;
    const snip = snippets.find((s) => s.id === msg.id);
    if (!snip) return;
    const target = isEditable(document.activeElement) ? document.activeElement : lastEditable;
    if (!isEditable(target)) return;
    insertAtCaret(target, snip);
  });
})();
