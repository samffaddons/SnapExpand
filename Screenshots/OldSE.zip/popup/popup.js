"use strict";

const STORAGE_SETTINGS_KEY = "snapexpand_settings";
const STORAGE_SNIPPETS_KEY = "snapexpand_snippets";

async function init() {
  const data = await browser.storage.local.get([STORAGE_SETTINGS_KEY, STORAGE_SNIPPETS_KEY]);
  const settings = Object.assign({ enabled: true }, data[STORAGE_SETTINGS_KEY] || {});
  const snippets = data[STORAGE_SNIPPETS_KEY] || [];

  const enabledBox = document.getElementById("popupEnabled");
  enabledBox.checked = settings.enabled;
  enabledBox.addEventListener("change", async () => {
    settings.enabled = enabledBox.checked;
    await browser.storage.local.set({ [STORAGE_SETTINGS_KEY]: settings });
  });

  const activeCount = snippets.filter((s) => s.enabled && s.trigger).length;
  document.getElementById("popupStat").textContent =
    activeCount === 1 ? "1 snippet active" : `${activeCount} snippets active`;

  document.getElementById("btnOpenSettings").addEventListener("click", () => {
    browser.runtime.openOptionsPage();
    window.close();
  });
}

init();
